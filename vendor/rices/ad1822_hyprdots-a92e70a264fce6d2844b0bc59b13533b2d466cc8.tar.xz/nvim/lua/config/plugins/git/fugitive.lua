return {
	"tpope/vim-fugitive",
}
