# Your personal Neovim tips

