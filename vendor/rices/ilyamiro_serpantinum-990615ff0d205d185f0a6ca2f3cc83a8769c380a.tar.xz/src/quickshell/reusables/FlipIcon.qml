import QtQuick
import QtQuick.Layouts
import QtQuick.Controls
import "../"

Item {
    id: root
    implicitWidth: size
    implicitHeight: size

    property int size: 44
    property int cornerRadius: 12

    property color accentColor: "#89b4fa"
    property color textColor: "#11111b"
    property color iconColor: textColor

    property bool flipped: false
    property bool autoToggle: true
    property bool action_highlight: false
    property string clickSound: "reusables/iconbutton/click.wav"

    signal clicked()
    signal triggered()
    signal toggled(bool flipped)

    property real flashOpacity: 0.0
    property real popScale: 1.0

    property bool isHoveredOrHighlighted: (btnMa.containsMouse || root.action_highlight) && root.enabled

    Rectangle {
        id: btnShape
        anchors.fill: parent
        radius: root.cornerRadius
        clip: true
        color: !root.enabled ? root.accentColor : (btnMa.pressed ? Qt.darker(root.accentColor, 1.12) : (root.isHoveredOrHighlighted ? Qt.lighter(root.accentColor, 1.12) : root.accentColor))
        opacity: root.enabled ? 1.0 : 0.5

        Behavior on color { ColorAnimation { duration: 180 } }
        Behavior on opacity { NumberAnimation { duration: 180 } }

        scale: (!root.enabled ? 1.0 : (btnMa.pressed ? 1.08 : (root.isHoveredOrHighlighted ? 1.04 : 1.0))) * root.popScale
        Behavior on scale { NumberAnimation { duration: 250; easing.type: Easing.OutQuint } }

        SequentialAnimation {
            id: btnPopAnim
            NumberAnimation { target: root; property: "popScale"; to: 1.1; duration: 110; easing.type: Easing.OutQuad }
            NumberAnimation { target: root; property: "popScale"; to: 1.0; duration: 420; easing.type: Easing.OutQuint }
        }

        Item {
            id: chevronWrapper
            anchors.centerIn: parent
            width: root.size * 0.38
            height: root.size * 0.38

            rotation: root.flipped ? 90 : -90
            Behavior on rotation { NumberAnimation { duration: 300; easing.type: Easing.OutBack } }

            property real armThickness: Math.max(1.5, root.size * 0.048)
            property real armLength: Math.max(5, root.size * 0.19)
            property real dotSize: armThickness

            Item {
                id: pivotNode
                x: (chevronWrapper.width - (chevronWrapper.armLength * 0.766)) / 2
                y: chevronWrapper.height / 2
                width: 0
                height: 0

                Rectangle {
                    anchors.centerIn: parent
                    width: chevronWrapper.dotSize
                    height: chevronWrapper.dotSize
                    radius: width / 2
                    color: root.iconColor
                    antialiasing: true
                    Behavior on color { ColorAnimation { duration: 180 } }
                }

                Rectangle {
                    x: 0
                    y: -chevronWrapper.armThickness / 2
                    width: chevronWrapper.armLength
                    height: chevronWrapper.armThickness
                    radius: height / 2
                    transformOrigin: Item.Left
                    rotation: 40
                    color: root.iconColor
                    antialiasing: true
                    Behavior on color { ColorAnimation { duration: 180 } }
                }

                Rectangle {
                    x: 0
                    y: -chevronWrapper.armThickness / 2
                    width: chevronWrapper.armLength
                    height: chevronWrapper.armThickness
                    radius: height / 2
                    transformOrigin: Item.Left
                    rotation: -40
                    color: root.iconColor
                    antialiasing: true
                    Behavior on color { ColorAnimation { duration: 180 } }
                }
            }
        }

        Rectangle {
            anchors.fill: parent
            radius: root.cornerRadius
            color: "#ffffff"
            opacity: root.flashOpacity
            PropertyAnimation on opacity { id: btnFlashAnim; to: 0; duration: 400; easing.type: Easing.OutExpo }
        }

        MouseArea {
            id: btnMa
            anchors.fill: parent
            hoverEnabled: root.enabled
            enabled: root.enabled
            cursorShape: root.enabled ? Qt.PointingHandCursor : Qt.ArrowCursor

            onClicked: {
                if (!root.enabled) return;
                if (root.autoToggle) {
                    root.flipped = !root.flipped;
                }
                btnPopAnim.start();
                root.flashOpacity = 0.4;
                btnFlashAnim.start();
                if (typeof Sounds !== "undefined") {
                    Sounds.playSfx(root.clickSound);
                }
                root.clicked();
                root.triggered();
                root.toggled(root.flipped);
            }
        }
    }
}
