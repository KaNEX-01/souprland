mainMod = "SUPER"
terminal = "kitty"
